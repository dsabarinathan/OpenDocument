# OpenDoc 🚀, AGPL-3.0 license

__version__ = "0.0.1"

# __init__.py
from .preprocessing import sauvola_thresholding,remove_Lines